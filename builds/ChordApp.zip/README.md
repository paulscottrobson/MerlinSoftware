# MerlinSoftware
Repository for FOSS for Seagull Merlin, Strumstick and similar.

Visit https://github.com/paulscottrobson/MerlinSoftware for the source.

Author: Paul Robson paul@robsons.org.uk

